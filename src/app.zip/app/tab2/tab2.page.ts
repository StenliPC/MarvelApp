import { Component, OnInit } from '@angular/core';
import { MarvelStoriesService } from '../Services/marvel-stories.service';
import { Stories } from '../models/stories';

@Component({
  selector: 'app-stories-search',
  templateUrl: './tab2.page.html',
  styleUrls: ['./tab2.page.scss']
})
export class StoriesSearchComponent implements OnInit {
  stories: any[] = [];
  filters: any = {}; // Může obsahovat limit, offset, orderBy, characters, atd.

  constructor(private marvelStoriesService: MarvelStoriesService) {}

  ngOnInit() {
    this.getStories();
  }

  getStories() {
    this.marvelStoriesService.getStories$(this.filters).subscribe((data: Stories) => {
      this.stories = data.data.results;
    });
  }

  // Metody pro změnu filtrů a opětovné načtení příběhů podle nových kritérií
  updateFilters(filterKey: string, filterValue: any) {
    this.filters[filterKey] = filterValue;
    this.getStories();
  }
}
