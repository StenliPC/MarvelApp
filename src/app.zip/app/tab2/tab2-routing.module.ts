import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // Pro ngModel
import { IonicModule } from '@ionic/angular';
import { StoriesSearchComponent } from './tab2.page';

@NgModule({
  declarations: [StoriesSearchComponent],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    // Další moduly, pokud je potřeba
  ],
  exports: [StoriesSearchComponent]
})
export class StoriesSearchModule {}
