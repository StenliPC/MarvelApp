import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Stories} from "../models/stories";
import * as md5 from "md5";
import {} from "../models/stories";

@Injectable({
  providedIn: 'root'
})
export class MarvelStoriesService {
  private publicKey = '7fe5025f70546ca798ba1a7fe1d55dc3';
  private privateKey = '91e095af50b02b8dce0cd5ff2da732b73d70f14a';
  private baseUrl = 'https://gateway.marvel.com:443/';
  private ts = 'timestamp';

  constructor(private http: HttpClient) {
  }


  private generateHash(timestamp: number) {
    return md5(timestamp + this.privateKey + this.publicKey);
  }

  // Get character details by ID
  /*getCharacters$():Observable<Characters> {
     const timestamp = new Date().getTime();
     const hash = this.generateHash(timestamp);
     const url = `${this.baseUrl}GET /v1/public/stories?ts=${timestamp}&apikey=${this.publicKey}&hash=${hash}&limit=90`;
     return this.http.get<Characters>(url);
   }*/
  getStories$(filters: any): Observable<Stories> {
    const timestamp = new Date().getTime();
    const hash = this.generateHash(timestamp);
    const url = `${this.baseUrl}GET /v1/public/stories?ts=${timestamp}&apikey=${this.publicKey}&hash=${hash}`;
    return this.http.get<Stories>(url)
  }
}
