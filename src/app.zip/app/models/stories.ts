export interface Stories
{
  "code": "int",
  "status": "string",
  "copyright": "string",
  "attributionText": "string",
  "attributionHTML": "string",
  "data": {
  "offset": "int",
    "limit": "int",
    "total": "int",
    "count": "int",
    "results": [
    {
      "id": "int",
      "title": "string",
      "description": "string",
      "resourceURI": "string",
      "type": "string",
      "modified": "Date",
      "thumbnail": {
        "path": "string",
        "extension": "string"
      },
      "comics": {
        "available": "int",
        "returned": "int",
        "collectionURI": "string",
        "items": [
          {
            "resourceURI": "string",
            "name": "string"
          }
        ]
      },
      "series": {
        "available": "int",
        "returned": "int",
        "collectionURI": "string",
        "items": [
          {
            "resourceURI": "string",
            "name": "string"
          }
        ]
      },
      "events": {
        "available": "int",
        "returned": "int",
        "collectionURI": "string",
        "items": [
          {
            "resourceURI": "string",
            "name": "string"
          }
        ]
      },
      "characters": {
        "available": "int",
        "returned": "int",
        "collectionURI": "string",
        "items": [
          {
            "resourceURI": "string",
            "name": "string",
            "role": "string"
          }
        ]
      },
      "creators": {
        "available": "int",
        "returned": "int",
        "collectionURI": "string",
        "items": [
          {
            "resourceURI": "string",
            "name": "string",
            "role": "string"
          }
        ]
      },
      "originalissue": {
        "resourceURI": "string",
        "name": "string"
      }
    }
  ]
},
  "etag": "string"
}
